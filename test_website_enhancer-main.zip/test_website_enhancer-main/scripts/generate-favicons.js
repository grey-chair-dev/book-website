#!/usr/bin/env node

/**
 * Favicon Generation Script
 * 
 * This script helps generate proper favicon files from SVG sources.
 * Run this when you want to create PNG/ICO versions of the favicons.
 * 
 * Requirements:
 * - Install sharp: npm install sharp
 * - Install png-to-ico: npm install png-to-ico
 */

const fs = require('fs');
const path = require('path');

console.log('🎨 Favicon Generation Script');
console.log('============================');
console.log('');
console.log('Current favicon files created:');
console.log('✅ public/favicon.svg - SVG favicon (32x32)');
console.log('✅ public/logo192.svg - SVG app icon (192x192)');
console.log('✅ public/favicon.ico - Placeholder ICO file');
console.log('');
console.log('To generate PNG/ICO versions:');
console.log('1. Install dependencies: npm install sharp png-to-ico');
console.log('2. Run: node scripts/generate-favicons.js');
console.log('');
console.log('The SVG favicons will work in modern browsers and provide:');
console.log('- Scalable graphics that look crisp at any size');
console.log('- Smaller file sizes');
console.log('- Better performance');
console.log('');
console.log('For older browser support, consider generating PNG/ICO versions.');
console.log('');

// Check if dependencies are available
try {
  require('sharp');
  require('png-to-ico');
  console.log('✅ Dependencies found! Ready to generate PNG/ICO files.');
} catch (error) {
  console.log('⚠️  Dependencies not found. Install with: npm install sharp png-to-ico');
} 